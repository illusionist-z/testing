<?php
$messages = array(
    "dashboard" => "ホム",
    "user_dashboard" => "ホム",
    "attend" => "会社院いる",
    "absent" =>"会社院ない",
    "manageuser" => "メンバー管理",
    "attendancelist" => "出勤リスト",
    "leaveday" => "休み日",
    "salary" => "給料",
    "current_time" => "今の時間",
    "late_reason" =>  "遅れの理由.",
    "last_member" => "最新メンバー",
    "new_member" => "新入社員",
    "attendance"    => "出勤",
    "leave"          => "休み",
    "checkin"       => "チェックイン",
    "checkout"     => "チェックウト",
    "home"       => "ホーム",
    "checkinout"=> "チェックイン/ウト",
    "latest_news" => "最新ニュース",
    "viewallmember" => "全てのメンバー"
);

