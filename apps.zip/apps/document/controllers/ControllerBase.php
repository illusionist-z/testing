<?php namespace salts\Document\Controllers;

// use library
use Library;

class ControllerBase extends Library\Core\Controller
{
    
}
