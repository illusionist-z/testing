<?php

$messages = array (
   "calendar"  => "Calendar",
   "event_enable" => "User Event Enable",
   "show_event"   => "Show Event",
   "create_event" => "Create Event",
    "edit_event"  => "Edit Event",
    "title"            => "Title",
    "name"         => "Name",
    "start_d"       => "Start Date",
    "end_d"       => "End Date",
    "create_btn"  => "Create",
    "edit_btn"    => "Edit",
    "delete_btn" => "Delete",
    "cancel_btn" => "Cancel",
   "chkevent"   => "Check above user to see their event",
   "home"   => "Home",
   "search_member"   => "Search Member",
   "add_member"   => "Add Member",
   "close"   => "Close",
   "title"   => "Title",
   "name"   => "Name",
   "start_date"   => "Start Date",
   "end_date"   => "End Date",
   "edit"   => "Edit",
   "delete"   => "Delete",
   "create"   => "Create",
   "cancel"   => "Cancel"
);

