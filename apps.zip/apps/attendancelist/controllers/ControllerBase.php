<?php namespace salts\Attendancelist\Controllers;

// use library
use Library;

class ControllerBase extends Library\Core\Controller
{

}
