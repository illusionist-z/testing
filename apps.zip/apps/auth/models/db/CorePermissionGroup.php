<?php namespace salts\Auth\Models\Db;

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class CorePermissionGroup extends \Library\Core\BaseModel{
    
     public $permission_code;
     public $page_rule_group;
     public $permission_group_code;
     public $permission_group_name;
}
