<?php namespace salts\Home\Controllers;

// use library
use Library;

class ControllerBase extends Library\Core\Controller
{
    
}
