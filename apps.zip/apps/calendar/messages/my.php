<?php

$messages = array(
"calendar"  => "ၿပကၡဒိန္",
"event_enable" => "ၿဖစ္စဥ္ခြင့္ၿပဳၿခင္း",
"show_event"  => "ၿဖစ္စဥ္ၿပၿခင္း",
"chkevent"   => "ျဖစ္စဥ္ကိုုစစ္ေဆးၾကည္႔ျခင္း",
"home"   => "မူလစာမ်က္ႏွာ",
"search_member"   => "မန္မာကိုုရွာေဖြပါ",
"add_member"   => "မန္ဘာအသစ္ထည္႔ရန္",
"close"   => "ပိတ္ပါ",
"title"   => "ေခါင္းစဥ္",
"name"   => "အမည္",
"start_date"   => "ရက္အစ",
"end_date"   => "ရက္အဆံုုး",
"edit"   => "ျပင္သညါ",
"delete"   => "ဖ်က္သည္",
"create"   => "ဖန္တီးသည္",
"cancel"   => "Cancel"
);
