<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$messages = array(
    "username" => "名前",
    "startdate" => "開始日",
    "enddate" =>"終わる日",
    "leavestatus" => "休暇のステータス",
    "leaveday" => "休暇",
    "leavecategory" => "休みtype",
    "leavedes" => "理由",
    
);

