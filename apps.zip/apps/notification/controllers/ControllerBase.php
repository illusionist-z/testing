<?php namespace salts\Notification\Controllers;

// use library
use Library;

class ControllerBase extends Library\Core\Controller
{
    
}
