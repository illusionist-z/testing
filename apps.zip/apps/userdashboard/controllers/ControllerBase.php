<?php namespace salts\UserDashboard\Controllers;

// use library
use Library;

class ControllerBase extends Library\Core\Controller
{
    
}
