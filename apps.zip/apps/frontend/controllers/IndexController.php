<?php namespace salts\Frontend\Controllers;

class IndexController extends ControllerBase
{

    public function indexAction()
    {
        echo 'front';
    }
   public function testAction(){
       echo 'test';
   }
}

