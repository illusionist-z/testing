<?php namespace salts\Setting\Controllers;

// use library
use Library;

class ControllerBase extends Library\Core\Controller
{
    
}
