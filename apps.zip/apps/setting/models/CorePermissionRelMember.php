<?php
namespace salts\Setting\Models;
use Phalcon\Mvc\Model;
 

class CorePermissionRelMember extends Model
{
public $rel_member_id;
public $rel_permission_group_code;
public $core_permission_rel_member;
public $permission_member_group_member_name;
public $permission_group_id_user;


}
 
 
 