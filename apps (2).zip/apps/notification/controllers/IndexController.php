<?php

namespace salts\Notification\Controllers;
use salts\Core\Models\Db\CoreMember;
 

class IndexController extends ControllerBase
{
    
    public function initialize() {
        parent::initialize();
          $this->act_name =  $this->router->getModuleName(); 
         $this->permission = $this->setPermission($this->act_name );        
        $this->view->module_name=$this->module_name;
        $this->view->permission = $this->permission;
            if($this->permission==1){
                //Go to user dashboard
               $permission="admin";
                 
            } 
            else {
                //Go to admin dashboard
                $permission="user";   
            }
         
        
        $this->view->setVar("permission",$permission);
               //$this->assets->addJs('common/js/notification.js');

    }

    
    public function indexAction(){
        
    }

    /**
     * @author Su Zin Kyaw <gnext.suzin@gmail.com>
     * Show All Notification in one page
     */
    public function viewallAction(){
          $this->act_name =  $this->router->getModuleName(); 
         $this->permission = $this->setPermission($this->act_name ); 
        $this->setCommonJsAndCss();

        $type=viewall;
        $Admin=new CoreMember();
        $id = $this->session->user['member_id'];
             if($this->permission==1){
                //Go to user dashboard
              $noti=$Admin->GetAdminNoti($id);
                 
            } 
           else {
                //Go to admin dashboard
               $noti=$Admin->GetUserNoti($id); 
            }
         

        $this->view->setVar("noti",$noti);
        $this->view->setVar("type",$type);
    }
    
    /**
     * @author Su Zin Kyaw <gnext.suzin@gmail.com>
     * when user seen noti and click ok update data
     */
    public function update_notiAction(){
       $noti_id=$this->request->getPost('noti_id');
       $update=new \salts\Notification\Models\CoreNotificationRelMember();
       $update->updateNoti($noti_id);
    }
    
    public function notificationAction(){
       //echo "aa";exit;
         $Admin=new CoreMember();
         $id = $this->session->user['member_id'];
         
               if($this->permission==1){
               
              $noti=$Admin->GetAdminNoti($id);
                 
            } 
            else {
                //Go to admin dashboard
               //echo"aa";exit;
               $noti=$Admin->GetUserNoti($id); 
            }
         

        $type='noti';        
        $this->view->setVar("noti",$noti);
        $this->view->setVar("type",$type);
         
    }
    
    public function detailAction(){
        $this->setCommonJsAndCss();
        $code=$this->session->permission_code;
        $Admin=new CoreMember();
        $id = $this->session->user['member_id'];
               if($this->permission==1)  {
                //Go to user dashboard
              $noti=$Admin->GetAdminNoti($id);
                 
            } 
            else {
                //Go to admin dashboard
               $noti=$Admin->GetUserNoti($id); 
            }
        
      
        $this->view->setVar("noti",$noti);
        $type="detail";
        $this->view->setVar("type",$type);
        $noti_id= $this->request->get('id');
        $module_name= $this->request->get('mname');
        $Noti_detail=new \salts\Notification\Models\CoreNotification();
        $Detail_result=$Noti_detail->GetNotiInfo($module_name, $noti_id);
        $this->view->setVar("module_name",$module_name);
        $this->view->setVar("result",$Detail_result);
         $this->view->t = $this->_getTranslation();

    }
    
    /**
     * notification for calendar
     * when someone add event on calendar
     */
    public function noticalendarAction(){
        
        $id=$this->request->get('id');
        $Noti=new \salts\Notification\Models\CoreNotification();
             
               if($this->permission==1){
                //Go to user dashboard
            $Noti->calendarnotification($id);                 
            } 
           else {
                //Go to admin dashboard
               $member_id=$this->session->user['member_id'];
            $Noti->usercalendarnotification($id,$member_id);
            }
        
//        if($this->session->permission_code=='ADMIN'){
//        }
//        else{
//            
//        }
        $this->response->redirect("calendar/index");
    }
    
     public function notiattendancesAction(){
        
        $id=$this->request->get('id');
        $Noti=new \salts\Notification\Models\CoreNotification();
        $Noti->attnotification($id);
        $this->response->redirect("attendancelist/index/todaylist");

      
    }
    
}

