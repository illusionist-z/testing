<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$messages = array(
    "username" => "User Name",
    "startdate" => "Start Date",
    "enddate" =>"End Date",
    "leavestatus" => "Leave Status",
    "leaveday" => "Leave Days",
    "leavecategory" => "Leave Category",
    "leavedes" => "Leave Description",
    
);


