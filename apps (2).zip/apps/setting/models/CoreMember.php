<?php
namespace salts\Setting\Models;

use Phalcon\Mvc\Model;

 
class CoreMember extends Model
{
 public $user_rule;
 public $member_login_name;
 public $user_rule_member_id;
 }
 
 
 
 
