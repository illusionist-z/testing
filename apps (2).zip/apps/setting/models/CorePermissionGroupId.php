<?php
namespace salts\Setting\Models;
use Phalcon\Mvc\Model;

/**
 * @author David JP <david.gnext@gmail.com>
 * @desc    Setting Core Permission Id
 */
 
class CorePermissionGroupId extends Model
{
 public $group_id;
 public $name_of_group;
}
 
 
 