<?php
namespace salts\Attendancelist\Models;
use Phalcon\Mvc\Model;

/**
 * @author Yan Lin Paii
 * @desc     Core Permission Id
 */
 
class CorePermissionGroupId extends Model
{
 public $group_id;
 public $name_of_group;
}
 
 
 