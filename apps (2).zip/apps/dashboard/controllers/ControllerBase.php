<?php namespace salts\Dashboard\Controllers;
// use library
use Library;

class ControllerBase extends Library\Core\Controller
{
    
}
