<?php
$messages = array(
    "dashboard" => "Dashboard",
    "user_dashboard" => "User Dashboard",
    "attend" => "Staffs Attended",
    "absent" =>"Staffs Absent",
    "manageuser" => "Manage User",
    "attendancelist" => "Attendance List",
    "leaveday" => "Leave Days",
    "salary" => "Salary",
    "current_time" => "Current Time",
    "late_reason" =>  "If You late,Check Here and write your reason.",
    "last_member" => "Lastest Members",
    "new_member" => "New Members",
    "attendance"   =>  "Attendance",
    "leave"          =>  "Leave",
    "checkin"        => "Check In",
    "checkout"       => "Check Out",
    "home"       => "Home",
    "checkinout" => "Check In / Check Out",
    "latest_news" => "Latest News",
    "no_leave" => "People who doesn't take leave",
    "viewallmember" => "View All Members"    
);

