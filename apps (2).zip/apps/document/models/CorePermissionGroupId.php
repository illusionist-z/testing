<?php
namespace salts\Document\Models;

use Phalcon\Mvc\Model;
use Phalcon\Mvc\Model\Query;
use Phalcon\Mvc\Controller;
use Phalcon\Filter;
/**
 * @author Yan Lin Pai
 * @desc     Core Permission Id
 */
 
class CorePermissionGroupId extends Model
{
 public $group_id;
 public $name_of_group;
}
 
 
 