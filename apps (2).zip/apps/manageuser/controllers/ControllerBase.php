<?php namespace salts\Manageuser\Controllers;

// use library
use Library;

class ControllerBase extends Library\Core\Controller
{
    
}
