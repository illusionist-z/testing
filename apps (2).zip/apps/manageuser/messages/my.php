<?php

$messages = array(
    "userlist" => "လူဦးေရစာရင္း", 
    "name"   => "နာမည္",
    "home"   => "ပင္မစာမ်က္ႏွာ",
    "dept"   => "ဌာန",
    "position" => "ရာထူး",
    "mail"     => "ေမးလ္",
    "phone" => "ဖုန္းနံပတ္",
    "address" => "လိပ္စာ",
    "adduser" => "၀န္ထမ္းသစ္ေပါင္းၿခင္း",
    "password" => "လ်ွိဳ႕၀ွက္ကုတ္",
    "confirm_pass" => "အတည္ၿပဳကုတ္",
    "user_role" => "ကဏ",
    "user_profile" => "အသံုးၿပဳပံု",
    "edit_user"  => "မြမ္းမံၿခင္း",        
    "id"     => "အသံုးၿပဳသူID",
    "w_start_dt" => "အလုုပ္စ၀င္တဲ႔ေန႔",
    "btn_edit" => "ျပင္ရန္",
    "btn_delete" => "ဖေက္ရန္",
    "btn_cancel" => "Cancel",
    "username" => "User Name",
    "placeholder1" => "အမည္ကိုုျဖည္႔ရန္",
    "placeholder2" => "နံမည္အျပည္႔အစံုုျဖည္႔ရန္",
    "placeholder3" => "လ်ွဳိ႔၀ွက္နံပါတ္",
    "placeholder4" => "လ်ွဳိ႔၀ွက္နံပတ္",
    "placeholder5" => "အလုုပ္စတဲ႔ေန႔",
    "placeholder6" => "အလုုပ္ဌာနအမည္ျဖည္႔ရန္",
    "placeholder7" => "ရထူး",
    "placeholder8" => "အီးေမးလ္",
    "placeholder9" => "ဖုုန္းနံပတ္ျဖည္႔ရန္",
    "placeholder10" => "လိပ္စာအျပည္႔အစံုုျဖည္႔ရန္"
);


